Numbers = [24,35,23,5,23,5,34,6,5,6,457,6,57,8546754,63,6357,46,87,5,8,5,7545,5,63,654555,4,675,35,6,34,7,35,63,45,2,6,75,5,68,568,573,4,2]

length = len(Numbers)
//pai xu
for i in range(length):
    for j in range(1, length - i):
        if(Numbers[j - 1] > Numbers[j]):
            Numbers[j - 1], Numbers[j] = Numbers[j], Numbers[j-1]

print(Numbers)