import jieba
import wordcloud

text = open("a.txt", 'r', encoding="utf-8").read()

list = jieba.lcut(text)

t = " ".join(list)

w = wordcloud.WordCloud(width=1920, height=1080, background_color='white', font_path="msyh.ttc")
//ci  yun
w.generate(t)
w.to_file('123.png')