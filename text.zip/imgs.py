import re,os,requests,userAgentdef

filePath = './imgsFile'

if not os.path.exists(filePath):
    os.mkdir(filePath)

url='https://www.qiushibaike.com/imgrank/'
headers = {
    'UserAgent':userAgentdef.getUserAgent()
}

htmltext=requests.get(url=url,headers=headers).text

# print(htmltext)

res = '<img src="(.*?.jpg)" .*? class="illustration" .*?>'

urlList=re.findall(res,htmltext)


for list in urlList:
    fileName=list.split('/')[-1]
    imgfile = requests.get(url='http:' + list, headers=headers)
    with open(filePath+'/'+fileName, 'wb') as f:
        f.write(imgfile.content)
        print(fileName+'      end')