def reverseString(str):
    strlist = list(str)
    strlist.reverse()
    str = "".join(strlist)
    return str

//qu fan 
if __name__ == '__main__':
    print("请输入字符串")
    str = input()
    print(reverseString(str))