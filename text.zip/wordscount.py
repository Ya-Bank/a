import jieba

text = open("threekingdoms.txt", 'r',encoding="utf-8").read()

wlist = jieba.lcut(text)

count={}

for list1 in wlist:
    if len(list1) < 2:
        continue
    else:
        count[list1] = count.get(list1, 0) + 1

item = list(count.items())

item.sort(key= lambda x:x[1], reverse=True)
//ci pin
for i in range(15):
    word, count = item[i]
    print(word, '    ', count)