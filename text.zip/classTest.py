class test:


    def setString(self, str):
        self.str = str

    def getString(self):
        return self.str
//2 input and out
if __name__ == '__main__':
    s = test()

    print('请输入字符串')
    str = input()
    s.setString(str)
    print("您输入的是",s.getString())

